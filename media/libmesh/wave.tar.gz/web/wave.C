/* $Id: ex8.C,v 1.14 2004/12/17 20:55:06 benkirk Exp $ */
/* The Next Great Finite Element Library. */
/* Copyright (C) 2003  Benjamin S. Kirk */

/* This library is free software; you can redistribute it and/or */
/* modify it under the terms of the GNU Lesser General Public */
/* License as published by the Free Software Foundation; either */
/* version 2.1 of the License, or (at your option) any later version. */

/* This library is distributed in the hope that it will be useful, */
/* but WITHOUT ANY WARRANTY; without even the implied warranty of */
/* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU */
/* Lesser General Public License for more details. */

/* You should have received a copy of the GNU Lesser General Public */
/* License along with this library; if not, write to the Free Software */
/* Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA */

#include <iostream>
#include <fstream>
#include <algorithm>
#include <stdio.h>
#include <math.h>
#include "libmesh.h"
#include "mesh.h"
#include "gmv_io.h"
#include "newmark_system.h"
#include "equation_systems.h"
#include "fe.h"
#include "quadrature_gauss.h"
#include "dense_matrix.h"
#include "dense_vector.h"
#include "sparse_matrix.h"
#include "numeric_vector.h"
#include "dof_map.h"

void assemble_wave(EquationSystems& es, const std::string& system_name);

void apply_initial(EquationSystems& es, const std::string& system_name);

void fill_dirichlet_bc(EquationSystems& es, const std::string& system_name);

int main (int argc, char** argv)
{
	libMesh::init (argc, argv);
	{
	if (argc < 7)
	{
		std::cerr << "Usage: " << argv[0] << " [meshfile]" << std::endl;
		error();
	}
	std::cout << "Running " << argv[0];
	for (int i=1; i<argc; i++) std::cout << " " << argv[i];
	std::cout << std::endl << std::endl;
	std::string mesh_file = argv[1];
	std::cout << "Mesh file is: " << mesh_file << std::endl;
	Real speed = atof(argv[2]);
	std::cout << "Speed is: " << speed << std::endl;

	const unsigned int dim = 2;
	Mesh mesh (dim);
	MeshData mesh_data(mesh);
	mesh.read(mesh_file, &mesh_data);
	mesh.print_info();
	//mesh.renumber_nodes_and_elements();
	const Real delta_t = atof(argv[3]);
	const Real max_t = atof(argv[4]);
	EquationSystems equation_systems (mesh);
	{
		equation_systems.add_system<NewmarkSystem> ("Wave");
		NewmarkSystem & t_system = equation_systems.get_system<NewmarkSystem>
			("Wave");
		t_system.add_variable("p", FIRST);
		t_system.attach_assemble_function  (assemble_wave);
		t_system.attach_init_function      (apply_initial);
		t_system.set_newmark_parameters(delta_t,atof(argv[5]),atof(argv[6]));
		equation_systems.parameters.set<Real>("speed")          = speed;
		equation_systems.parameters.set<Real>("fluid density")  = 1000.;
		equation_systems.parameters.set<Real>("time")           = 0.;
		equation_systems.init();
		equation_systems.print_info();
	}

	NewmarkSystem& t_system=equation_systems.get_system<NewmarkSystem> ("Wave");
	t_system.assemble();

	Real t_time = 0.;
	Real timetowrite = 0.;
	int lastpercent=0;
	int gmvn=0;
	for (t_time=0.; t_time<max_t+0.0001; )
	{
		const int percent = ((int) (20*100.0*t_time/max_t+0.5))/20;
		if (lastpercent != percent && percent % 5 == 0) 
		{
			std::cout << percent << "%" << std::endl;
			lastpercent=percent;
		}
		
		t_time += delta_t;

		equation_systems.parameters.set<Real>("time")  = t_time;
		t_system.update_rhs();
		if (fabs(t_time-delta_t) < TOLERANCE) //for the first time only
		{
			equation_systems.parameters.set<bool>("Newmark set BC for Matrix")
				= true;
			fill_dirichlet_bc(equation_systems, "Wave");
			equation_systems.parameters.set<bool>("Newmark set BC for Matrix") 
				= false;
		}
		else
			fill_dirichlet_bc(equation_systems, "Wave");
		t_system.solve();

		if (fabs(timetowrite) < TOLERANCE)
		{
//			std::cout << "  w:" << gmvn << " "<<t_time << std::endl;
			char buf[14];
			sprintf (buf, "out/out.%03d.gmv", gmvn++);
			GMVIO(mesh).write_equation_systems (buf, equation_systems);
			timetowrite=0.1;
		}
		timetowrite-=delta_t;

		t_system.update_u_v_a();
//		std::cout << "       time:"<<t_time << " "<<percent << "%" <<std::endl;
	}
//	std::cout << "  w?:" << timetowrite << std::endl;
	}
	return libMesh::close ();
}

void assemble_wave(EquationSystems& es, const std::string& system_name)
{  
	assert (system_name == "Wave");

	const Mesh& mesh = es.get_mesh();
	const unsigned int dim = mesh.mesh_dimension();
	const Real speed = es.parameters.get<Real>("speed");
	const Real rho   = es.parameters.get<Real>("fluid density");
	NewmarkSystem & t_system = es.get_system<NewmarkSystem> (system_name);
	FEType fe_type = t_system.get_dof_map().variable_type(0);
	SparseMatrix<Number>&   stiffness = t_system.get_matrix("stiffness");
	SparseMatrix<Number>&   damping   = t_system.get_matrix("damping");
	SparseMatrix<Number>&   mass      = t_system.get_matrix("mass");
	NumericVector<Number>&  force     = t_system.get_vector("force");
	SparseMatrix<Number>&  matrix     = *t_system.matrix;
	DenseMatrix<Number>    zero_matrix;
	AutoPtr<FEBase> fe (FEBase::build(dim, fe_type));
	QGauss qrule (dim, SECOND);
	fe->attach_quadrature_rule (&qrule);
	const std::vector<Real>& JxW = fe->get_JxW();
	const std::vector<std::vector<Real> >& phi = fe->get_phi();
	const std::vector<std::vector<RealGradient> >& dphi = fe->get_dphi();
	const DofMap& dof_map = t_system.get_dof_map();
	DenseMatrix<Number>   Ke, Ce, Me;
	DenseVector<Number>   Fe;
	std::vector<unsigned int> dof_indices;
	MeshBase::const_element_iterator       el     = mesh.elements_begin();
	const MeshBase::const_element_iterator end_el = mesh.elements_end();

	for ( ; el != end_el; ++el)
	{
		const Elem* elem = *el;
		dof_map.dof_indices (elem, dof_indices);
		fe->reinit (elem);
		{
			const unsigned int n_dof_indices = dof_indices.size();

			Ke.resize          (n_dof_indices, n_dof_indices);
			Ce.resize          (n_dof_indices, n_dof_indices);
			Me.resize          (n_dof_indices, n_dof_indices);
			zero_matrix.resize (n_dof_indices, n_dof_indices);
			Fe.resize          (n_dof_indices);
		}
		for (unsigned int qp=0; qp<qrule.n_points(); qp++)
		{
			for (unsigned int i=0; i<phi.size(); i++)
			for (unsigned int j=0; j<phi.size(); j++)
			{
				Ke(i,j) += JxW[qp]*(dphi[i][qp]*dphi[j][qp]);
				Me(i,j) += JxW[qp]*phi[i][qp]*phi[j][qp]*1./(speed*speed);
			} 
		} 
		if (!true)
		for (unsigned int side=0; side<elem->n_sides(); side++)
			if (elem->neighbor(side) == NULL)
		{
			AutoPtr<FEBase> fe_face (FEBase::build(dim, fe_type));
			QGauss qface(dim-1, SECOND);
			fe_face->attach_quadrature_rule (&qface);
			const std::vector<std::vector<Real> >& phi_face =fe_face->get_phi();
			const std::vector<Real>& JxW_face = fe_face->get_JxW();
			fe_face->reinit(elem, side);
			const Real acc_n_value = 1.0;
			for (unsigned int qp=0; qp<qface.n_points(); qp++)
			{
				for (unsigned int i=0; i<phi_face.size(); i++)
					Fe(i) += acc_n_value*rho*phi_face[i][qp]*JxW_face[qp];
			} 
		} 
		stiffness.add_matrix (Ke, dof_indices);
		damping.add_matrix   (Ce, dof_indices);
		mass.add_matrix      (Me, dof_indices);
		force.add_vector     (Fe, dof_indices);
		matrix.add_matrix(zero_matrix, dof_indices);
	} 
}

void apply_initial(EquationSystems& es, const std::string& system_name)
{
  NewmarkSystem & t_system = es.get_system<NewmarkSystem> (system_name);
  NumericVector<Number>&  pres_vec       = t_system.get_vector("displacement");
  NumericVector<Number>&  vel_vec        = t_system.get_vector("velocity");
  NumericVector<Number>&  acc_vec        = t_system.get_vector("acceleration");

  pres_vec.zero();
  vel_vec.zero();
  acc_vec.zero();
}

void fill_dirichlet_bc(EquationSystems& es, const std::string& system_name)
{
	assert (system_name == "Wave");
	NewmarkSystem & t_system = es.get_system<NewmarkSystem> (system_name);
	SparseMatrix<Number>&  matrix = *t_system.matrix;
	NumericVector<Number>& rhs    = *t_system.rhs;
	const Mesh& mesh = es.get_mesh();
	const Real pi = libMesh::pi;
	const bool do_for_matrix = es.parameters.get<bool>
		("Newmark set BC for Matrix");
	//const bool do_for_matrix = true;
	const Real current_time = es.parameters.get<Real>("time");
	unsigned int n_nodes = mesh.n_nodes();

	for (unsigned int n_cnt=0; n_cnt<n_nodes; n_cnt++)
	{
		const Node& curr_node = mesh.node(n_cnt);
		const Real y_coo1 = 0.;
		const Real y_coo2 = 1.;
		unsigned int dn = curr_node.dof_number(0,0,0);
		const Real penalty = 1.e10;
		const Real period = 1;
		Real p_value;
		if (fabs(curr_node(1)-y_coo1) < TOLERANCE)
		{
			//if (current_time < period && fabs(curr_node(0)-0.5)<0.15)
			if (current_time < period)
				p_value = sin(2*pi*current_time/period);
			else
				p_value = 0.0;
			//std::cout << p_value << std::endl;
			//std::cout << dn << " ";
			rhs.add(dn, p_value*penalty);
			if (do_for_matrix) matrix.add(dn, dn, penalty);
		}
		/*if (fabs(curr_node(1)-y_coo2) < TOLERANCE)
		{
			p_value = .0;
			rhs.add(dn, p_value*penalty);
			if (do_for_matrix) matrix.add(dn, dn, penalty);
		}*/
	} 
}
